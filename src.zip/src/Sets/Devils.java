package Sets;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;   //Tree set is order set and Tree not acepted null value

public class Devils {

	public static void main(String[] args) {
		Set<String> devils = new TreeSet<>();   //Tree set is order set and Tree not acepted null value 
		System.out.println("My Empty set:"+devils);
		devils.add("Komala");
		devils.add("Sandra");
		devils.add("Shivangi");
		devils.add("Thanuja");
		devils.add("Jyothi");
		devils.add("Teja");
		devils.add("Krian");
		
		System.out.println("My empty set after adding:"+devils);
		devils.remove("Ravan");   // set is unorder that why we have to put the values
		System.out.print("My empty set After Removing:"+devils);
		
		
		for(String nums : devils) {
			System.out.println("My empty set using Loop:"+nums);
		}
		((TreeSet<String>)devils).add("Akhila");
		((TreeSet<String>)devils).add("Akhila");
		System.out.println("My empty set first:"+devils);
	}

}
