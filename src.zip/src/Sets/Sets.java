package Sets;
import java.util.Set;    // set is un-order set and set not accepted null value 
import java.util.HashSet;
import java.util.TreeSet;   //Tree set is order set and Tree not accepted null value

public class Sets {

	public static void main(String[] args) {
		Set<String> gods = new HashSet<>(); 
//		Set<String> gods = new TeeSet<>();
		System.out.println("My Empty set:"+gods);
		gods.add("Ram");
		gods.add("Ravan");
		gods.add("Laxman");
		gods.add("Bharath");
		gods.add("Satrugnu");
		gods.add("Seeta");
		gods.add("Ram");
		
		System.out.println("My empty set after adding:"+gods);
		gods.remove("Ravan");   // set is unorder that why we have to put the values
		System.out.print("My empty set After Removing:"+gods);
		
		
		for(String nums : gods) {
			System.out.println("My empty set using Loop:"+nums);
		}
		((HashSet<String>)gods).add("Akhila");
		((HashSet<String>)gods).add("Akhila");
//		((TreeSet<String>)gods).add("Akhila");
		System.out.println("My empty set first:"+gods);
	}

}
