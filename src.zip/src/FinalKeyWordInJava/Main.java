package FinalKeyWordInJava;

class FinalKeyWord{  //user define class   //parent
	public void final_method1() {
		System.out.println("I am parent final method");
	}
}
class Final extends FinalKeyWord{   //child
	public void final_method2() {
		System.out.println("I am child final method");
		}
}
public class Main {  //main class
//	static int a = 100;
//	a = 500;
	public static void main(String[] args) {
		final int a = 100;
//		a = 500;
		System.out.println("A value: " + a);    
	    Final obj = new Final();
	    obj.final_method1(); // Calls parent method
	    obj.final_method2();  // Calls child method
	}
}
