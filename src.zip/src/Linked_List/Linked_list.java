package Linked_List;

import java.util.LinkedList;
import java.util.List;

public class Linked_list {

	public static void main(String[] args) {
		List<String> heros = new LinkedList<>();
		System.out.println("My Linked List:"+heros);
		

		heros.add("AAA"); 
		heros.add("BBB");
		heros.add("CCC");
		heros.add("DDD");
		heros.add("EEE");
		System.out.println("My linked list after adding:"+heros);
		
		heros.remove(4);  
		System.out.println("My linked list after removing:"+heros);
		
		String temp = heros.get(0);
		System.out.println("My linked list AAA:"+temp);
		
		for(String nums : heros) {
			System.out.println("My linked list using Iterators:"+nums);
		}
		((LinkedList<String>)heros).addFirst("Sandra");
		((LinkedList<String>)heros).addLast("Sandra");
		System.out.println("My linked list adding first:"+heros);
	}

}

//How to explain in exam:
// 1) Define
// 2) Syntax
// 3) add()
// 4) remove()
// 5) set()
// 6) for loop

// linear data structure: Array, stack, queue, Linked-list
// on linear data structure: trees, Graphs
