package Linked_List;

import java.util.LinkedList;
import java.util.List;

public class LinkedList_heroins {
	public static void main(String[] args) {
		List<String> heroines = new LinkedList<>();
		System.out.println("My Linked List:"+heroines);
		

		heroines.add("Sandra"); 
		heroines.add("Thanuja");
		heroines.add("Shivangi");
		heroines.add("Komala");
		heroines.add("Teja");
		System.out.println("My linked list after adding:"+heroines);
		
		heroines.remove(4);  
		System.out.println("My linked list after removing:"+heroines);
		
		String temp = heroines.get(0);
		System.out.println("My linked list AAA:"+temp);
		
		for(String nums : heroines) {
			System.out.println("My linked list using Iterators:"+nums);
		}
		((LinkedList<String>)heroines).addFirst("Akhila");
		((LinkedList<String>)heroines).addLast("Akhila");
		System.out.println("My linked list adding first:"+heroines);

	}

}
