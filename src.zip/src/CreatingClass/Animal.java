package CreatingClass;

public class Animal {
	public static void dog() {
		System.out.println("BoW Bow...!!");
	}

}
