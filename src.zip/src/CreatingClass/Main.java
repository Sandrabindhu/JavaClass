package CreatingClass;

public class Main {

	public static void main(String[] args) {
		Animal obj = new Animal();
		obj.dog();

	}

}
