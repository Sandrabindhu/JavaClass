package Exception_Handling;

class SandraExp extends Exception{
	public SandraExp(String msg) {    //constuctor
		super(msg);
	}
}

public class Custom_Exceptions {//Main class

	public static void main(String[] args) {   //this is very easy and importend
		try {
			throw new SandraExp("My constructor");
		}catch(SandraExp e) {
			System.out.println("My Custom error:"+e);
		}finally {
			System.out.println("My Custom error created successfully");
		}
	}
}
