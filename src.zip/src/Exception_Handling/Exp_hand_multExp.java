package Exception_Handling;

public class Exp_hand_multExp {

	public static void main(String[] args) {
		try {
//			//ArithmeticException--1
//			int div = 10/0;
//			//ArrayIndexOutOfBoundsException--2
//			
//			int []numbers = {1,2,3,4,5};
			String []fruits = {"Apple","Banana","Orange","Grapes","Pinapple"};
//			System.out.println("My number:"+numbers[10]);
			System.out.println("My number:"+fruits[10]);
			
			//StringIndexOutOfBoundsException--3
			
			String name = "Sandra";
			System.out.println("My name:"+name.charAt(15));
			
			//NullPointerException--4
			String a = null;
			System.out.println("My String:"+a.length());
		}catch(ArithmeticException e) {
			System.out.println("My 1st exp:"+e);
			
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("My 2nf exp:"+e);
			
		}catch(StringIndexOutOfBoundsException e) {
			System.out.println("My 3rd exp:"+e);
			
		}catch(NullPointerException e) {
			System.out.println("My 4th exp:"+e);
			
		}finally {
			System.out.println("My four exception is solving");
		}

	}

}
