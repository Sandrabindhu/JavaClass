package Exception_Handling;

class VotingException extends Exception { 
    public VotingException(String msg) {
        super(msg);
    }
}

public class VotingAgeCheck_HW {
    public static void main(String[] args) {
        try {
            checkVotingEligibility(16); // Change age to test different cases
        } catch (VotingException e) {
            System.out.println("Voting Error: " + e.getMessage());
        } finally {
            System.out.println("Voting age verification completed.");
        }
    }

    public static void checkVotingEligibility(int age) throws VotingException {
        if (age < 18) {
            throw new VotingException("You are not eligible to vote. Minimum age is 18.");
        } else {
            System.out.println("You are eligible to vote!");
        }
    }
}