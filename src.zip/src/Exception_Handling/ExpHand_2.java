package Exception_Handling;

public class ExpHand_2 {

	public static void main(String[] args) {
		String  name = null;
		System.out.println("My name is:"+name.length());
		
//		try {
//			String  name = "Sandra";
//			System.out.println("My name is:"+name.charAt(10));
//		}catch(StringIndexOutOfBoundsException e) {
//			System.out.println("My Error:"+e);
//		}	
	}

}
