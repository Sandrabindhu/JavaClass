//Exception Handling in Java:
package Exception_Handling;

public class Exp_hand {
	public static void main(String[] args) {
//		int a=10;
//		int b=0;
//		int div = a/b;
//		System.out.println("Div of:"+div);
		
		try {
			int a=10;
			int b=0;
			int div = a/b;
			System.out.println("Div of:"+div);
			
		}
		catch(ArithmeticException e){
			System.out.println("My error"+e);
			
		}
		finally {
			System.out.println("Error Solving");
		}
	}
}
