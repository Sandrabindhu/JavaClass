package Exception_Handling;

class AkhilSandra extends Exception{
	public AkhilSandra(String msg) {
		super(msg);
	}
}

public class Throws_Keyword {

	public static void main(String[] args) {
		try {
//			throw new AkhilSandra("I am Wife of Akhil");
			
			checkAkhil("AKHIL");
		}catch(AkhilSandra e) {
			System.out.println("My error:"+e);
		}finally {
			System.out.println("My AkhilSandra error....");
		}
	}
	public static void checkAkhil(String Akhil) throws AkhilSandra{
		if(Akhil.equals("Akhil")) {
			throw new AkhilSandra("I am Wife of Akhil");
		}else {
			throw new AkhilSandra("Akhil is husband of me");
		}
	}

}





