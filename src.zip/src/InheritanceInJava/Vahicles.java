package InheritanceInJava;

class Vahicle {  //parent or super or derived class
	public void Vahicle_method(){
		System.out.println("Car1 Name: ABC");
		System.out.println("Car1 Price: 20K");
	}
}

class car1 extends Vahicle{
	public void car1_method(){
		System.out.println("Car2 Name: DFG");
		System.out.println("Car2 Price: 50K");
	}
}

class car2 extends Vahicle{
	public void car2_method(){
		System.out.println("I am child method");
	}
}
public class Vahicles {   //main class

	public static void main(String[] args) {
		car1 c1 = new car1();
		c1.Vahicle_method();
		c1.car1_method();
		System.out.println();
		car2 c2 = new car2();
		c2.Vahicle_method();
		c2.car2_method();
		System.out.println();

	}

}
      

