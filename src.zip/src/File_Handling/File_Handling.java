package File_Handling;
import java.io.FileWriter;
import java.io.IOException;
public class File_Handling {

	public static void main(String[] args) {
		try {
			FileWriter java = new FileWriter("Java.txt");
			java.write("Java is High level, "+"Programming Language");
			java.close();
			System.out.println("File Created");
		}
		catch(IOException e) {
			System.out.println("File not Found Error");
			e.printStackTrace();
		}
	}

}



//Operatios:
// 1) read()
// 2) write()
// 3) open()
// 4) close()