package File_Handling;

import java.io.FileReader;
import java.io.BufferedReader;   //BufferReader means to loading data from A to B and B to A
import java.io.IOException;

public class File_open {

	public static void main(String[] args) {
		try {
			BufferedReader read_java = new BufferedReader(new FileReader("Java.txt"));
			String temp;
			while((temp=read_java.readLine())!=null) {
				System.out.println(temp);
				
			}
			read_java.close();
		}
		catch(IOException e) {
			System.out.println("File not Found Error");
			e.printStackTrace();
		}
		

	}

}
