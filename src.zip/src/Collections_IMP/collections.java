package Collections_IMP;

import java.util.List; // it can access any data set
import java.util.ArrayList;   //it can access same data set

public class collections {

	public static void main(String[] args) {
		//array can't bossible to all at a time
		int [] number = {100, 200, 300, 400, 500};  
		System.out.println("My numbers normal array:"+number[3]);
		
		// In java first we have to create empty list then only we can load the list
		List<Integer> numbers = new ArrayList<>();  // in this data type must be capital letter
		System.out.println("My numbers list before:"+numbers);
		
		numbers.add(100); //Adding in to empty list
		numbers.add(200);
		numbers.add(300);
		numbers.add(400);
		numbers.add(500);
		System.out.println("My numbers list after:"+numbers);
		
		int temp = numbers.get(0);
		System.out.println("My numbers list temp:"+temp);
		//VVVVIMP
		numbers.remove(0);  //it is to pop up or to remove some elements
		System.out.println("My numbers list after removing:"+numbers);
		
		for(int nums : numbers) {
			System.out.println("My numbers list using Iterators:"+nums);
		}
		
		
	}

}
// list
// set
// dict
// tuple
// array---->(collection)
// maps
// Linked list

// array and array list are different


//----Primitive data type:
// int, long, char, float, double, string, bool, byte
// imp: array, list, collection must come in exam.