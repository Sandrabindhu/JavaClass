package Collections_IMP;
import java.util.List; // it can access any data set
import java.util.ArrayList;   //it can access same data set
public class flowers_collections {

	public static void main(String[] args) {
	
		List<String> flowers = new ArrayList<>();  // in this data type must be capital letter
		System.out.println("My flowers list before:"+flowers);
		
		flowers.add("Lotus"); 
		flowers.add("Lily");
		flowers.add("Rose");
		flowers.add("Sunflower");
		flowers.add("Jasmine");
		System.out.println("My flowers list after:"+flowers);
		
		flowers.remove(0);  
		System.out.println("My numbers list after removing:"+flowers);
		
		for(String nums : flowers) {
			System.out.println("My numbers list using Iterators:"+nums);

		}
	}
}
	
