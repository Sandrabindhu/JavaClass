package Maps;
import java.util.Map;
import java.util.TreeSet;
import java.util.HashMap;

public class Maps {

	public static void main(String[] args) {
		Map<String,Integer> birds = new HashMap<>();
		System.out.println("My empty map:"+birds);
		birds.put("Sparrow", 1);
		birds.put("Egale", 1);
		birds.put("Falcon", 1);
		birds.put("Phenonix", 1);
		birds.put("Parote", 1);
		
		System.out.println("My empty set after adding:"+birds);
		birds.remove("Engle");   // set is unorder that why we have to put the values
		System.out.print("My empty set After Removing:"+birds);
		
		
		for(Map.Entry<String,Integer> entry: birds.entrySet()) {
			System.out.println("Keys:=>"+entry.getKey()+","+"Values:=>"+entry.getValue());
		}
	}

}
//HW: Tree Map   (employee:  employee_id)
//1) put()
//2) remove()
//3) for()




// fi - means function
// md - means methods