package StaticVariableOrMethodsInJavs;

class car{  //use defined class
	private String car_name;   //non static or instance
	private String car_col;
	
	car(String car_name, String car_col){  //this is constructor
		this.car_name =car_name; 
		System.out.println("Car name is:" + car_name);
		this.car_col =car_col; 
		System.out.println("Car colour is:" + car_col);
	}
	
	public void car_method() {
		System.out.println("Car name is using method is:" + car_name);
		System.out.println("Car colour is using method is:" + car_col);
	}
}
public class thisKeyWordInJava {  //main class

	public static void main(String[] args) {
		car c =new car("HUNdai", "REd");
		  
		c.car_method();
		
	}
}
