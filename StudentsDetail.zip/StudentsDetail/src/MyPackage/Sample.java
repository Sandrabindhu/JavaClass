package MyPackage;

public class Sample {
	public void demo() {
		System.out.println("Demo");
	}
}
