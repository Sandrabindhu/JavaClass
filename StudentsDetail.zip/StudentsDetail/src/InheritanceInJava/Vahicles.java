package InheritanceInJava;

class Vahicle {  //parent or super or derived class
	public void Vahicle_method(){
		System.out.println("Car1 Name: ABC");
		System.out.println("Car1 Price: 20K");
	}
}

class car1 extends Vahicle{
	public void car1_method(){
		System.out.println("Car2 Name: DFG");
		System.out.println("Car2 Price: 50K");
	}
}

class car2 extends Vahicle{
	public void car2_method(){
		System.out.println("I am child method");
	}
}
public class Vahicles {   //main class

	public static void main(String[] args) {
		car1 c = new car1();
		c.Vahicle_method();
		c.car1_method();
		c.car2_method();
		System.out.println();

	}

}
