package SetterGetter;

public class parent {
	
	private int sid;
	private String sname;
	
	public int getSid() {   //getter 1
		return sid;
	}
	public void setSid(int sid) {
		this.sid= sid;
	}
	public static void main(String[] args) {
		parent p = new parent();
		p.setSid(101);
		System.out.println("Student id:" + p.getSid());
	}

}
