package Project_1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class Student {
    String name;
    int age;
    String course;

    public Student(String name, int age, String course) {
        this.name = name;
        this.age = age;
        this.course = course;
    }

    public String toString() {
        return name + " | " + age + " | " + course;
    }
}

public class StudentManagementGUI {
    private JFrame frame;
    private DefaultListModel<String> studentListModel;
    private JList<String> studentList;
    private ArrayList<Student> students = new ArrayList<>();

    public StudentManagementGUI() {
        frame = new JFrame("Student Management System");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Student List
        studentListModel = new DefaultListModel<>();
        studentList = new JList<>(studentListModel);
        frame.add(new JScrollPane(studentList), BorderLayout.CENTER);

        // Buttons Panel
        JPanel panel = new JPanel();
        JButton addButton = new JButton("Add Student");
        JButton deleteButton = new JButton("Delete");
        panel.add(addButton);
        panel.add(deleteButton);
        frame.add(panel, BorderLayout.SOUTH);

        // Add Student Button Action
        addButton.addActionListener(e -> addStudent());

        // Delete Student Button Action
        deleteButton.addActionListener(e -> deleteStudent());

        frame.setVisible(true);
    }

    private void addStudent() {
        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField courseField = new JTextField();
        Object[] fields = {"Name:", nameField, "Age:", ageField, "Course:", courseField};

        int option = JOptionPane.showConfirmDialog(frame, fields, "Add Student", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            String course = courseField.getText();

            Student student = new Student(name, age, course);
            students.add(student);
            studentListModel.addElement(student.toString());
        }
    }

    private void deleteStudent() {
        int index = studentList.getSelectedIndex();
        if (index != -1) {
            students.remove(index);
            studentListModel.remove(index);
        }
    }

    public static void main(String[] args) {
        new StudentManagementGUI();
    }
}