package Instance_of_keyword;

class Animal{   //parent
	
}

class Dog extends Animal{    //child
	
}

public class sample {

	public static void main(String[] args) {
		Animal a = new Animal();
		Dog d = new Dog();
		System.out.println(a instanceof Animal);
		System.out.println(d instanceof Animal);

	}

}
