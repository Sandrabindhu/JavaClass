package Composition;

class Engine{    //parent 1
	void start() {
		System.out.println("Engine Start");
	}
}
class Car{   //parent 2
	
	Engine e = new Engine();
	
	void stop() {
		System.out.println("Engine Stop");
		e.start();
	}
}

class EngineMove{   //parent 2
	
	Engine e = new Engine();
	
	void move() {
		System.out.println("Engine Moved");
		
	}
}

public class Composition {  //Main class

	public static void main(String[] args) {
		Car c = new Car();
		EngineMove e = new EngineMove();
		e.move();
		c.stop();
	}

}
