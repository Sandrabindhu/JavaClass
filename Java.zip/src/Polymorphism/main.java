package Polymorphism;
//Ploymorphism in java: CTE, RTE


////CTE(Method over loading)
//public class main {
//
//	public static int add(int a, int b) {   //method 1
//		return a+b;
//	}
//	public static double add(double a, double b) {    //method 2
//		return a+b;
//	}
//	public static void main(String[] args) {
//		System.out.println("method 1:" +add(20,20));
//		System.out.println("method 2:" +add(100,200));
//
//	}
//
//}

//RTE
class animal{  //parent
	public void sound() {
		System.out.println("Animal Sound");
	}
}
class dog extends animal{  //child1
	@Override
	public void sound() {
		System.out.println("BOW BOW");
	}
}

class cat extends animal{  //child2
	@Override
	public void sound() {
		System.out.println("Mew Mew");
	}
}
public class main {
	public static void main(String[] arg) {
		dog d= new dog();
		cat c= new cat();
		c.sound();
		d.sound();
		
	}
}

