package Students;
import java.util.Date;
public class DateTime {

	public static void main(String[] args) {
		System.out.println("Current Date");
		System.out.println("------------");
		Date obj = new Date();
		System.out.print(obj);
	}

}
