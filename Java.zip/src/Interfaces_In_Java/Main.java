package Interfaces_In_Java;


interface Animal{
	abstract void sound();  // interface always access the abstract keyword
}
class Horse implements Animal{   //
	public void sound() {
		System.out.println("WOOF WOOF WOOF");
	}
}
class Tiger implements Animal{   //
	public void sound() {
		System.out.println("ROWR ROWR ROWR");
	}
}
public class Main {

	public static void main(String[] args) {
		Horse a = new Horse();
		Tiger t = new Tiger();
		a.sound();
		t.sound();
	}

}


//Employee Details:
//Empid
//EmpName
//Emp_sal
//Emp_loc
//Emp_pho