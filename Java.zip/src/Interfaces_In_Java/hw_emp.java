package Interfaces_In_Java;

interface Employee {
    abstract void displayDetails(); // Method to display employee details
}

class Employee1 implements Employee {
    public void displayDetails() {
        System.out.println("Empid: 101");
        System.out.println("EmpName: John");
        System.out.println("Emp_sal: 50,000");
        System.out.println("Emp_loc: New York");
        System.out.println("Emp_pho: 1234567890");
    }
}

class Employee2 implements Employee {
    public void displayDetails() {
        System.out.println("Empid: 102");
        System.out.println("EmpName: Jane");
        System.out.println("Emp_sal: 60,000");
        System.out.println("Emp_loc: California");
        System.out.println("Emp_pho: 9876543210");
    }
}

public class hw_emp {
    public static void main(String[] args) {
        Employee1 e1 = new Employee1();
        Employee2 e2 = new Employee2();
        e1.displayDetails();
        e2.displayDetails();
    }
}



//Employee Details:
//Empid
//EmpName
//Emp_sal
//Emp_loc
//Emp_pho