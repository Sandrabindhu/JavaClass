package Abstraction;

abstract class Flowers{    //parent
	abstract void smell();   // abstract method have no body like  "{ }" 
}

class Rose extends Flowers{
	@Override
	void smell(){     // normal method
		System.out.println("ROSE SMELL");
	}
}

class Lily extends Flowers{
	@Override
	void smell(){     // normal method
		System.out.println("Lily SMELL");
	}
}

public class Abstraction {

	public static void main(String[] args) {
		Rose r = new Rose();
		Lily l = new Lily();
		r.smell();
		l.smell();
	}

}
