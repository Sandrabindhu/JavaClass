package Implimentation_of_abstraction;

import java.util.Scanner;
import java.util.Random;

abstract class ATM { // Parent class
    double balance; // Initial balance
    int pin; // User PIN

    ATM(double balance, int pin) { // Parent constructor
        this.balance = balance;
        this.pin = pin;
    }

    abstract void withDraw(double amount);

    abstract void deposit(double amount);

    abstract void changePin(int oldPin, int newPin);

    abstract void generateOtp();

    abstract void checkBal();
}

class SBI extends ATM {
    SBI(double balance, int pin) {
        super(balance, pin);
    }

    // Withdraw Method
    @Override
    void withDraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdraw success: Available Balance: " + balance);
        } else {
            System.out.println("Insufficient Balance or Invalid Amount.");
        }
    }

    @Override
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit success: Available Balance: " + balance);
        } else {
            System.out.println("Deposit failed. Invalid Amount.");
        }
    }

    @Override
    void changePin(int oldPin, int newPin) {
        if (oldPin == pin) {
            pin = newPin;
            System.out.println("PIN successfully updated!");
        } else {
            System.out.println("Incorrect old PIN. Try again.");
        }
    }

    @Override
    void generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Generate a 6-digit OTP
        System.out.println("Your OTP is: " + otp);
    }

    @Override
    void checkBal() {
        System.out.println("Available Balance: " + balance);
    }
}

public class Main_ATM {

    public static void main(String[] args) {
        SBI obj = new SBI(2000, 1234); // Initialize with default balance and PIN
        Scanner s = new Scanner(System.in);

        while (true) {
            System.out.println("****ATM-MENU****");
            System.out.println("1. Withdraw Money");
            System.out.println("2. Deposit Money");
            System.out.println("3. Check Balance");
            System.out.println("4. Change PIN");
            System.out.println("5. Generate OTP");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = s.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter amount to withdraw: ");
                    double withAmt = s.nextDouble();
                    obj.withDraw(withAmt);
                    break;
                case 2:
                    System.out.print("Enter amount to deposit: ");
                    double depAmt = s.nextDouble();
                    obj.deposit(depAmt);
                    break;
                case 3:
                    obj.checkBal();
                    break;
                case 4:
                    System.out.print("Enter old PIN: ");
                    int oldPin = s.nextInt();
                    System.out.print("Enter new PIN: ");
                    int newPin = s.nextInt();
                    obj.changePin(oldPin, newPin);
                    break;
                case 5:
                    obj.generateOtp();
                    break;
                case 6:
                    System.out.println("Thank you! Visit again...!!!");
                    System.exit(0);
                default:
                    System.out.println("Enter a valid option.");
            }
        }
    }
}

// add 2 methods : HW
// to change pin 
//otp generate
