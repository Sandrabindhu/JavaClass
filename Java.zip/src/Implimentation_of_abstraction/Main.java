package Implimentation_of_abstraction;
import java.util.Scanner;

abstract class Apps{   //Abstract parent class
	
	String user_name;
	String passward;
	
	void user_input() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter username: ");
		user_name = s.nextLine();
		System.out.println("Enter password: ");
		passward = s.nextLine();
	}
	
	void user_login() {
		System.out.println("WELCOME TO INSTRAGRAM");
		System.out.println("---------------------");
		System.out.println("Please Login Here...!");
	}
	
	abstract void app_open();     //Abstract method
}

class Instagram extends Apps{     //child class
	@Override
	void app_open() {       //normal method
		
		while(true) {
		
		if(user_name.equals("SANDRA B") && passward.equals("123@")) {
			System.out.println("Successfully Login, App is open...!!");
			break;
		}
		else {
			System.out.println("Invaid username and password : Please try again!");
			user_input();
		}
		}
	}
}

public class Main {

	public static void main(String[] args) {
		Instagram i = new Instagram();
		i.user_login();
		i.user_input();
		i.app_open();
	}

}
