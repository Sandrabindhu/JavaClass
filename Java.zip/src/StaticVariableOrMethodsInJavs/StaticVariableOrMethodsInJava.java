package StaticVariableOrMethodsInJavs;

public class StaticVariableOrMethodsInJava {
	
	//Variables
	int a = 100;  // non static or instance var
	static int b = 200; //static var 
	
	//Methods
	public void non_static() {    //non static or instance method
		System.out.println("IN NON STATIC OR INSTANCE METHOD");
	}	
	public static void static1() {    // static method
		System.out.println("IN STATIC METHOD");
	}
	public static void main(String[] args) {
		StaticVariableOrMethodsInJava m = new StaticVariableOrMethodsInJava();
		
		//Calling variables
		System.out.println("a value:" + m.a);  //required obj because non static or instance
		System.out.println("a value:" + b);  //not required because static
		
		//Calling method
		m.non_static();//required obj because non static 
		static1();//not required because static
	}
}
