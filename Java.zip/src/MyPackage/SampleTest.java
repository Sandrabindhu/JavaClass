package MyPackage;

public class SampleTest {

	public static void main(String[] args) {
		Sample s = new Sample();
		s.demo();

	}

}
