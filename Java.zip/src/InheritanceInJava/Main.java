package InheritanceInJava;

class parent{  //parent or super or derived class
	public void parent_method(){
		System.out.println("I am parent method");
	}
}

class child1 extends parent{
	public void child_method(){
		System.out.println("I am child method");
	}
}

class child2 extends child1{
	public void child_method(){
		System.out.println("I am child method");
	}
}
public class Main {   //main class

	public static void main(String[] args) {
		child1 c =new child1();
		c.parent_method();
		c.child_method();
		System.out.println();

	}

}
