package Modifires;

class Modi{    //user define class
	public int a = 100;
	protected int b = 200;
	int c =300;
	private String  d = "Sandra";   // in user defied class can't able to access the private 
	
	public String getName() {  //With getter method we can take private
		return d;   //getter method
	}
	public void setName(String d){
		this.d=d;
	}
}

public class Modifires {   //main class
	
	public int a = 100;    //public modifires  // without static after public then we must have to create object 
	
	protected int b = 200;   //protected
	
	int c =300;   //default modifires
	
	private String  d = "Sandra"; //Private
	
	public static void main(String[] args) {
		
		//main class object
		Modifires m = new Modifires();
		System.out.println("a value: " +m.a);
		System.out.println("b value: " +m.b);
		System.out.println("c value: " +m.c);
		System.out.println("Ny name: " +m.d);
		
		//user defined class object
		Modi m1 = new Modi();
		System.out.println("a value: " +m1.a);
		System.out.println("b value: " +m1.b);
		System.out.println("c value: " +m1.c);
		m1.setName("Sandra");
		System.out.println("Ny name: " +m1.getName());
		
	}

}
